import React from "react";
import "./Buttons.css";

function NavButton() {
  return (
    <a href="signup">
      <button className="btn">Sign jklUp</button>
    </a>
  );
}

export default NavButton;
import react, { Component } from'react';
import {Button} from 'reactstrap';
import './Readmore.css';

class Readmore extends Component{
    render(){
        return(
            <div>
            <Button >Read more</Button>
            </div>
        )
    }
}
export default Readmore;
